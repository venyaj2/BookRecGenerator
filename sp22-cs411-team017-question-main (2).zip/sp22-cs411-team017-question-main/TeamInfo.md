# Team017-BookRecommender Team Question

## Basic Information

|   Info      |        Description     |
| ----------- | ---------------------- |
| TeamID      |         Team-017       |
| TeamName    |        question        |
| Captain     |   Lingxiao Mou         |
| Captain     |      lmou2@illinois.edu|
| Member1     |   Tommaso Bassetto     |
| Member1     |   tommaso3@illinois.edu|
| Member2     |   Chahna Saraiya   |
| Member2     |   csarai2@illinois.edu |
| Member3     |   Venya Joshi          |
| Member3     |   venyaj2@illinois.edu |

## Project Information

|   Info      |        Description     |
| ----------- | ---------------------- |
|  Title      |    Book Recommender    |
| System URL  |      link_to_system    |
| Video Link  |      link_to_video     |

## Project Summary
Our project will be a book recommendation system. The user can enter their ratings of books and let an algorithm decide, sort by long/short books, ratings, etc. Potentially, we could also add a feature to get recommendations from friends. See doc/PROPOSAL.md for more details.
